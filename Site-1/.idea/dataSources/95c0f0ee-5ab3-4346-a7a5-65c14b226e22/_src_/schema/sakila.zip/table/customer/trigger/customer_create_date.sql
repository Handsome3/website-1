CREATE TRIGGER sakila.customer_create_date
BEFORE INSERT ON sakila.customer
FOR EACH ROW
  SET NEW.create_date = NOW();
